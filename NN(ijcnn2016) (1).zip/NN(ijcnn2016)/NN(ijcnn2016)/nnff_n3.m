function [nn,TrainMSE] = nnff_n3(nn, x, y)  % perform Loss =1/2*FN^2/P+1/2*FP^2/N
%NNFF performs a feedforward pass
% nn = nnff(nn, x, y) returns an neural network structure with updated
% layer activations, error and loss (nn.a, nn.e and nn.L)

    n = nn.n;
    m = size(x, 1);
    
    x = [ones(m,1) x];
    nn.a{1} = x;

    %feedforward pass
    for i = 2 : n-1   % from layer 2 to layer (n-1) are the feature learning layers ,while the last layer(layer n) is the classfification layer,it can have different function than the previous layers
        switch nn.activation_function 
            case 'sigm'
                % Calculate the unit's outputs (including the bias term)
                nn.a{i} = sigm(nn.a{i - 1} * nn.W{i - 1}');
            case 'tanh_opt'
                nn.a{i} = tanh_opt(nn.a{i - 1} * nn.W{i - 1}');
        end
        
        %dropout
        if(nn.dropoutFraction > 0)
            if(nn.testing)
                nn.a{i} = nn.a{i}.*(1 - nn.dropoutFraction);
            else
                nn.dropOutMask{i} = (rand(size(nn.a{i}))>nn.dropoutFraction);
                nn.a{i} = nn.a{i}.*nn.dropOutMask{i};
            end
        end
        
        %calculate running exponential activations for use with sparsity
        if(nn.nonSparsityPenalty>0)
            nn.p{i} = 0.99 * nn.p{i} + 0.01 * mean(nn.a{i}, 1);
        end
        
        %Add the bias term
        nn.a{i} = [ones(m,1) nn.a{i}];
    end
    switch nn.output    % the activation function of the output layer can be different from the activation function of the previous layers
        case 'sigm'
            nn.a{n} = sigm(nn.a{n - 1} * nn.W{n - 1}');
        case 'linear'
            nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
        case 'softmax'
            nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
            nn.a{n} = exp(bsxfun(@minus, nn.a{n}, max(nn.a{n},[],2)));
            nn.a{n} = bsxfun(@rdivide, nn.a{n}, sum(nn.a{n}, 2)); 
    end

    %error and loss
	labels = nnpredict(nn, x(:,[2:end]));
	N1=length(find(labels==1));
	P1=length(find(labels==2));
    nn.e = y - nn.a{n};   % the error term 
    N=sum(y(:,1))+0.01;%the number of negtive samples,in case of the number of negtive samples in this batch is 0,we add 1
	P=sum(y(:,2))+0.01;%th  number of positive samples,in case of the number of positive samples in this batch is 0,we add 1
    switch nn.output    % softmax regression has its own loss function different from other general loss function 
        case {'sigm', 'linear'}
		 		 
		 L1=0;L2=0;L11=0;L22=0;
		 for i=1:size(nn.e,1) 
		   if y(i,1)==1
		    L1= L1+1/2 *(sum(nn.e(i,:) .^ 2));
           else 
		    L2= L2+1/2 * (sum(nn.e(i,:) .^ 2)); 
           end		   
         end
		 for k=1:size(nn.e,1) 
		   if labels(k)==1
		      L11=L11+1/2*(sum(nn.e(k,:).^ 2));
		   else 
		      L22= L22+1/2 * (sum(nn.e(k,:) .^ 2)); 
           end		   
         end
		 
		  nn.L=(L1/N+L2/P+L11/N1+L22/P1);
		  TrainMSE = 1/2 * sum(sum(nn.e .^ 2)) / m;
             % loss function:1/2*(y-h)^2,y is the desired label while h is the predicted label
        case 'softmax'
            nn.L = -sum(sum(y .* log(nn.a{n}))) / m;  %loss function: -y*logh,y is the desired label while h is the predicted label
    end
end
