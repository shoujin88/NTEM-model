function [accuracy_ave,au1,au2,er,bad,Precision,Recall,F_Measure,MSE,FPN1,FPN2,FPN] = nntest_n1(nn, x, y);
   


    labels = nnpredict(nn, x);
    [dummy, expected] = max(y,[],2);
	
	aa=find(expected==1);%The samples whose true label are 1
	bb=find(expected==2);%The samples whose true label are 2
	labels_1=labels(aa); %the predicted label for those true label is 1
	labels_2=labels(bb); %the predicted label for those true label is 2
	% FOR imbalanced data, we use minority group as positive group
	
	TP=size(find(labels_1==1),1);FP=size(find(labels_2==1),1);FN=size(find(labels_1==2),1);   
	Precision=TP/(TP+FP);Recall=TP/(TP+FN); F_Measure=2*Recall*Precision/(Precision+Recall);
	
	au1=size(find(labels_1==1),1)/size(labels_1,1);au2=size(find(labels_2==2),1)/size(labels_2,1);
	accuracy_ave=(au1+au2)/2;
	
    bad = find(labels ~= expected);  %number of misclassfied samples  
    er = numel(bad) / size(x, 1);    %error rate
	
	MSE=1/2*sum((expected-labels).^2)/size(x,1);
	
     FPN1=1/2*sum((expected(aa)-labels(aa)).^2)/length(aa);  %FN^2/P
	 FPN2=1/2*sum((expected(bb)-labels(bb)).^2)/length(bb); %FP^2/N
	 FPN=FPN1+FPN2;
end

