clear all;


rand('state',0)
%train dbn
dbn.sizes = [100 100];
opts.numepochs =   1;
opts.batchsize = 100;
opts.momentum  =   0;
opts.alpha     =   1;
dbn = dbnsetup(dbn, train_x, opts);
dbn = dbntrain(dbn, train_x, opts);

%unfold dbn to nn
nn = dbnunfoldtonn(dbn, 2);
nn.activation_function = 'sigm';

%train nn
opts.numepochs =  1;
opts.batchsize = 100;
nn = nntrain(nn, train_x, train_y, opts);
% [er, bad] = nntest(nn, test_x, test_y);
% [accuracy_ave,au1,au2,er,bad,Precision,Recall,F_Measure]=nntest_n1(nn, test_x, test_y);

%%make ROC curve for the classifier on the dataset
[p,expected,er,bad,Precision,Recall,F_Measure]=nntest_n4(nn, test_x, test_y,0.5);
[X,Y,T,AUC] = perfcurve(expected,p,1);
plot(X,Y);
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC')