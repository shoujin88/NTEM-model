function [loss,TrainMSE] = nneval_n3(nn, loss, TrainMSE,train_x, train_y, val_x, val_y)  %evaluate the trained nn on the whole training samples by compute loss values using nnff
%NNEVAL evaluates performance of neural network     After each iterations ,it has a check on the loss value on whole traninig samples
% Returns a updated loss struct
assert(nargin == 5 || nargin == 7, 'Wrong number of arguments');

nn.testing = 1;


% training performance
[nn,MSE]         = nnff_n3(nn, train_x, train_y);
loss.train.e(end + 1) = nn.L;  % nn.L is the loss values between the desired vector values and the output layer vector values on the whole traning samples
TrainMSE=[TrainMSE,MSE];
% validation performance
if nargin == 6
    [nn]         = nnff_n2(nn, val_x, val_y);
    loss.val.e(end + 1)   = nn.L; % nn.L is the MSE between the desired vector and the output layer vector values
end
nn.testing = 0;
%calc misclassification rate if softmax
if strcmp(nn.output,'softmax')
    [er_train, dummy]               = nntest(nn, train_x, train_y);
    loss.train.e_frac(end+1)    = er_train;     % er_train is the misclassfication rate of the net on the test data
    
    if nargin == 6
        [er_val, dummy]             = nntest(nn, val_x, val_y);
        loss.val.e_frac(end+1)  = er_val;  % er_val is the misclassfication rate of the net on the test data
    end
end

end
