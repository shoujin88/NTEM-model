function [labels,p] = nnpredict_n4(nn, x,threshold)  %threshold is the threshold value for classification, when p(1)>thershold, the sample would be calssified to class 1,otherwise to class 2
    nn.testing = 1;
    nn = nnff(nn, x, zeros(size(x,1), nn.size(end)));
    nn.testing = 0;
    
	p=nn.a{end}(:,1)./sum(nn.a{end},2);  % the probability of the sample belongs to class 1
	T=threshold(ones(size(p,1),1));
    
    [dummy, i] = max([p,T],[],2);
    labels = i;
end
