function [nn,dd] = nnff_n1(nn, x, y)
%NNFF performs a feedforward pass
% nn = nnff(nn, x, y) returns an neural network structure with updated
% layer activations, error and loss (nn.a, nn.e and nn.L)
  P=sum(y(:,2));N=sum(y(:,1));
    n = nn.n;
    m = size(x, 1);
    
    x = [ones(m,1) x];
    nn.a{1} = x;    % pass the original feature data to nn as the first layer nn.a{1}

    %feedforward pass
    for i = 2 : n-1   % from layer 2 to layer (n-1) are the feature learning layers ,while the last layer(layer n) is the classfification layer,it can have different function than the previous layers
        switch nn.activation_function 
            case 'sigm'
                % Calculate the unit's outputs (including the bias term)
                nn.a{i} = sigm(nn.a{i - 1} * nn.W{i - 1}');
            case 'tanh_opt'
                nn.a{i} = tanh_opt(nn.a{i - 1} * nn.W{i - 1}');
        end
        
        %dropout
        if(nn.dropoutFraction > 0)
            if(nn.testing)
                nn.a{i} = nn.a{i}.*(1 - nn.dropoutFraction);
            else
                nn.dropOutMask{i} = (rand(size(nn.a{i}))>nn.dropoutFraction);
                nn.a{i} = nn.a{i}.*nn.dropOutMask{i};
            end
        end
        
        %calculate running exponential activations for use with sparsity
        if(nn.nonSparsityPenalty>0)
            nn.p{i} = 0.99 * nn.p{i} + 0.01 * mean(nn.a{i}, 1);
        end
        
        %Add the bias term
        nn.a{i} = [ones(m,1) nn.a{i}];
    end
    switch nn.output    % the activation function of the output layer can be different from the activation function of the previous layers
        case 'sigm'
		for i=1:size(y,1) 
		   if y(i,1)==1    %add cost sensitive factors N/(N+P), P/(N+P) to the intput of the last layer
		    nn.a{n - 1}(:,1)=N/(N+P)*nn.a{n - 1}(:,1);
		    nn.a{n - 1}(:,2)=P/(N+P)*nn.a{n - 1}(:,1);
           else 
		    nn.a{n - 1}=P/(N+P)*nn.a{n - 1};
           end
		end
            nn.a{n} = sigm(nn.a{n - 1} * nn.W{n - 1}');
        case 'linear'
            nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
        case 'softmax'
            nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
            nn.a{n} = exp(bsxfun(@minus, nn.a{n}, max(nn.a{n},[],2)));
            nn.a{n} = bsxfun(@rdivide, nn.a{n}, sum(nn.a{n}, 2)); 
    end

    %error and loss
    nn.e = y - nn.a{n};   % the error term 
	dd=zeros(size(y));
	%split the samples into minority group and majority group
	y_mi_index=find(y(:,1)==1);  %the index of the minority samples
    y_ma_index=find(y(:,2)==1); %the index of the majority samples
	a_mi=nn.a{n}([y_mi_index],:); % the output(predicted labels) of the minority samples
	a_ma=nn.a{n}([y_ma_index],:);
	y_mi=y([y_mi_index],:); % the true labels of the minority samples
	y_ma=y([y_ma_index],:);
	
	nn_e_mi=y_mi-a_mi;
	nn_e_ma=y_ma-a_ma;
	P=length(y_ma);N=length(y_mi);
	%COST sensitive parameters like N/(N+P),P/(N+P
	nn_e_mi_1=(N/(N+P))*nn_e_mi(:,1);
	nn_e_mi_2=(P/(N+P))*nn_e_mi(:,2);
	nn_e_mi=[nn_e_mi_1,nn_e_mi_2];
	
	d_mi = -nn_e_mi.*(a_mi .* (1 - a_mi));
    d_ma	= -P/(N+P)*nn_e_ma.*(a_ma .* (1 - a_ma));
	dd([y_mi_index],:)=d_mi;
	dd([y_ma_index],:)=d_ma;
	
	
    switch nn.output    % softmax regression has its own loss function different from other general loss function 
        case {'sigm', 'linear'}
            nn.L = 1/2 * (sum(sum((y_mi-a_mi) .^ 2)) /N + sum(sum((y_ma-a_ma) .^ 2)) /P); % loss function:1/2*(y-h)^2,y is the desired label while h is the predicted label
        case 'softmax'
            nn.L = -sum(sum(y .* log(nn.a{n}))) / m;  %loss function: -y*logh,y is the desired label while h is the predicted label
    end
end
