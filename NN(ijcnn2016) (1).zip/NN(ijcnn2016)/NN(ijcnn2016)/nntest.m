function [er, bad] = nntest(nn, x, y)
    labels = nnpredict(nn, x);  % the output label is a real value for each sample
    [dummy, expected] = max(y,[],2); % get the label value from the label vector
    bad = find(labels ~= expected);  %number of misclassfied samples  
    er = numel(bad) / size(x, 1);    %error rate
end
