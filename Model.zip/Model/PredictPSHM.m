uidx = [3,1,1,6]; items = {[8], [1,2], [3,5], [11,13]};
userhid = BinaryForward( uidx, Q_WU.W1, Q_WU.W2 );
itemhid = BinaryForwardMulti( items, Q_WI.W1, Q_WI.W2 );
mid = [userhid; itemhid];
scores = OutScores( mid, Q_WC.W1, Q_WC.W2 );
[~, rankItems] = sort(scores, 'descend');