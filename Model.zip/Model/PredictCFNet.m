uidx = double(rand(size(Q_WU.W,2), 3) > 0.8); idxs = {[1,2,3],[1,2,3],[4,5,6]};
itemhid1 = BinaryBinaryForward( uidx, Q_WU.W);
itemhid2 = BinaryForwardMulti( idxs, Q_WI.W1, Q_WI.W2 );
[scores] = OutScores( [itemhid1; itemhid2], Q_WC.W1, Q_WC.W2 );
[~, zz] = sort(scores);