nFeat = 20; nItem = 50;
dataset = cell(1, 100);
parfor i=1:length(dataset)
    nsItem = ceil(rand(1,1) * 10) + 1;
    dataset{i}.Session = unique(ceil(rand(1,nsItem)*nItem));
end
FeatureDict = ones(nFeat, nItem);
caseData = MakeCFNetDataCases(dataset);
CFNet;