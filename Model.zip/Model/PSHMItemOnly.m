%% Parameters
Epoch = 20;
nSamples = 10;
batchSz = 4;
nNegUsers = 2;
nNegItems = 5;
nMid = 50; nHid = 50;

aplha = 1;
negUserPr = aplha .* ones(nUser, 1);
negItemPr = aplha .* ones(nItem, 1);

nCases = size(caseData, 1);
for i=1:nCases
    userIdx = caseData(i,2);
    itemIdx = caseData(i,4);
    negUserPr(userIdx) = negUserPr(userIdx) + 1;
    negItemPr(itemIdx) = negItemPr(itemIdx) + 1;
end

negUserPr = negUserPr.^0.75;
negUserPr = negUserPr / sum(negUserPr);
negItemPr = negItemPr.^0.75;
negItemPr = negItemPr / sum(negItemPr);

%% init Q params
Q_WI = InitBilinearWeights(nItem, nMid, nHid);
Q_WC = InitSoftmaxParams(nHid, nMid, nItem);

%% init P params
P_WI = InitSoftmaxParams(nHid, nMid, nItem);
P_WC = InitSoftmaxParams(nItem, nMid, nHid);

%% init Q Gradient params
QGrad_I.G1 = InitAdagradParam(size(Q_WI.W1)); QGrad_I.G2 = InitAdagradParam(size(Q_WI.W2));
QGrad_C.G1 = InitAdagradParam(size(Q_WC.W1)); QGrad_C.G2 = InitAdagradParam(size(Q_WC.W2));

%% init P Gradient params
PGrad_I.G1 = InitAdagradParam(size(P_WI.W1)); PGrad_I.G2 = InitAdagradParam(size(P_WI.W2));
PGrad_C.G1 = InitAdagradParam(size(P_WC.W1)); PGrad_C.G2 = InitAdagradParam(size(P_WC.W2));

nbatch = ceil(nCases / batchSz);
for ep = 1:Epoch
    fprintf('\nEpoch %d starting...', ep);
    
    LL = 0;
    caseData = caseData(randperm(nCases), :);
    for i=1:nbatch
        deltaLL = 0;
        [batch, actualSz] = MakePSHMMiniBatch(dataset, caseData, negUserPr, nNegUsers, negItemPr, nNegItems, i, batchSz);
        
        [itemhid, Q_LL] = SampleBinaryUnitsMulti(batch.Items, Q_WI.W1, Q_WI.W2, nSamples);
        itemhid = double(itemhid);
        deltaLL = deltaLL - Q_LL;
        LL = LL + Q_LL;
        
        Q_LL = BinarySoftmaxLL( itemhid, batch.Choices, Q_WC.W1, Q_WC.W2);
        deltaLL = deltaLL - Q_LL;
        LL = LL + Q_LL;
        
        P_LL = BinaryBinaryLL(batch.Choices, itemhid, P_WC.W1, P_WC.W2);
        deltaLL = deltaLL + P_LL;
        
        P_LL = BinarySoftmaxMultiLL(itemhid, batch.Items, P_WI.W1, P_WI.W2);
        deltaLL = deltaLL + P_LL;
        
        deltaLL = NormalizeLL(deltaLL);
        weights = exp(deltaLL) ./ sum(exp(deltaLL));
        
        %% recoganition network
        % item model
        [Q_WI, QGrad_I] = QItemModel(batch.Items, itemhid, Q_WI, QGrad_I, weights);
        
        % output choice
        [Q_WC, QGrad_C] = QChoiceModel(itemhid, batch.Choices, negItemPr, batch.ItemNSamp, Q_WC, QGrad_C, weights);
        
        % generative network
        % input choice
        [P_WC, PGrad_C] = PChoiceModel(batch.Choices, itemhid,P_WC, PGrad_C, weights);
        
        % item model
        [P_WI, PGrad_I] = PItemModel(itemhid, batch.Items, negItemPr, batch.ItemNSamp, P_WI, PGrad_I, weights);
        
        
        fprintf('\n\tBatch %d/%d finished', i, nbatch);
    end
    
    fprintf('\nEpoch %d/%d finished, Q-Loglikelihood: %g\n', ep, Epoch, max(LL));
end

% for ep = 1:5
%     fprintf('\nEpoch %d starting...', ep);
%
%     caseData = caseData(randperm(nCases), :);
%     for i=1:nbatch
%         % output choice
%         [batch, actualSz] = MakePSHMMiniBatch(dataset, caseData, negUserPr, nNegUsers, negItemPr, nNegItems, i, batchSz);
% %         userhid = BinaryForward( batch.Users, Q_WU.W1, Q_WU.W2 );
%         itemhid = BinaryForwardMulti( batch.Items, Q_WI.W1, Q_WI.W2 );
%
%         [gdW1, gdW2, updateIdx, gdW2Neg, updateNegIdx] = SoftmaxLayer(itemhid, batch.Choices, negItemPr, nSamples, Q_WC.W1, Q_WC.W2, 1);
%         [ grad, QGrad_C.G1 ] = RMSPropUpdate( gdW1, QGrad_C.G1);
%         Q_WC.W1 = Q_WC.W1 + grad;
%         [ grad, QGrad_C.G2(updateIdx, :) ] = RMSPropUpdate( gdW2, QGrad_C.G2(updateIdx, :));
%         Q_WC.W2(updateIdx, :) = Q_WC.W2(updateIdx, :) + grad;
%         [ grad, QGrad_C.G2(updateNegIdx, :) ] = RMSPropUpdate( gdW2Neg, QGrad_C.G2(updateNegIdx, :));
%         Q_WC.W2(updateNegIdx, :) = Q_WC.W2(updateNegIdx, :) + grad;
%     end
% end


function [QParam, QGrad] = QItemModel(input, output, QParam, QGrad, weights)
[gdW1, gdW2, updateIdx] = BinaryLayerMulti(input, output, QParam.W1, QParam.W2, weights);
[ grad, QGrad.G2 ] = RMSPropUpdate( gdW2, QGrad.G2);
QParam.W2 = QParam.W2 + grad;

[ grad,  QGrad.G1(:,updateIdx) ] = RMSPropUpdate( gdW1, QGrad.G1(:,updateIdx));
QParam.W1(:,updateIdx) = QParam.W1(:,updateIdx) + grad;
end

function [QParam, QGrad] = QChoiceModel(input, output, negItemPr, nSamps, QParam, QGrad, weights)
[gdW1, gdW2, updateIdx, gdW2Neg, updateNegIdx] = SoftmaxLayer(input, output, negItemPr, nSamps, QParam.W1, QParam.W2, weights);
[ grad, QGrad.G1 ] = RMSPropUpdate( gdW1, QGrad.G1);
QParam.W1 = QParam.W1 + grad;
[ grad, QGrad.G2(updateIdx, :) ] = RMSPropUpdate( gdW2, QGrad.G2(updateIdx, :));
QParam.W2(updateIdx, :) = QParam.W2(updateIdx, :) + grad;
[ grad, QGrad.G2(updateNegIdx, :) ] = RMSPropUpdate( gdW2Neg, QGrad.G2(updateNegIdx, :));
QParam.W2(updateNegIdx, :) = QParam.W2(updateNegIdx, :) + grad;
end

function [PParam, PGrad] = PItemModel(input, output, negItemPr, itemNSamp, PParam, PGrad, weights)
[gdW1, gdW2, updateIdx, gdW2Neg, updateNegIdx] = SoftmaxLayerMulti(input, output, negItemPr, itemNSamp, PParam.W1, PParam.W2, weights);
[ grad, PGrad.G1 ] = RMSPropUpdate( gdW1, PGrad.G1);
PParam.W1 = PParam.W1 + grad;
[ grad, PGrad.G2(updateIdx, :) ] = RMSPropUpdate( gdW2, PGrad.G2(updateIdx, :));
PParam.W2(updateIdx, :) = PParam.W2(updateIdx, :) + grad;
[ grad, PGrad.G2(updateNegIdx, :) ] = RMSPropUpdate( gdW2Neg, PGrad.G2(updateNegIdx, :));
PParam.W2(updateNegIdx, :) = PParam.W2(updateNegIdx, :) + grad;
end

function [PParam, PGrad] = PChoiceModel(input, output, PParam, PGrad, weights)
[gdW1, gdW2, updateIdx] = BinaryLayer(input, output, PParam.W1, PParam.W2, weights);
[ grad, PGrad.G2 ] = RMSPropUpdate( gdW2, PGrad.G2);
PParam.W2 = PParam.W2 + grad;
[ grad, PGrad.G1(:,updateIdx) ] = RMSPropUpdate( gdW1, PGrad.G1(:,updateIdx));
PParam.W1(:,updateIdx) = PParam.W1(:,updateIdx) + grad;
end