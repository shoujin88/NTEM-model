nUser = 10; nItem = 20;
dataset = cell(1, 100);
userIdx = ceil(nUser*rand(length(dataset),1));
for i=1:length(dataset)
    dataset{i}.User = userIdx(i);
    session = [mod(i, nItem) + 1, mod(i+1, nItem) + 1, mod(i+2, nItem) + 1];
    dataset{i}.Session = session;
end
caseData = MakePSHMDataCases(dataset);
PSHM;