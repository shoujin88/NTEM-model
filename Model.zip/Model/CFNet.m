%% Parameters
Epoch = 10;
nSamples = 10;
batchSz = 5;
nNegSamps = 10;
nMid = 50; nHid = 50;

aplha = 1;
negUserPr = aplha .* ones(nUser, 1);
negItemPr = aplha .* ones(nItem, 1);

nCases = size(caseData, 1);
for i=1:nCases
    itemIdx = caseData(i,3);
    negUserPr(userIdx) = negUserPr(userIdx) + 1;
    negItemPr(itemIdx) = negItemPr(itemIdx) + 1;
end

negUserPr = negUserPr.^0.75;
negUserPr = negUserPr / sum(negUserPr);
negItemPr = negItemPr.^0.75;
negItemPr = negItemPr / sum(negItemPr);

%% init Q params
Q_WU = InitLayerWeight(nFeat, nHid);
Q_WI = InitBilinearWeights(nItem, nMid, nHid);
Q_WC = InitBilinearWeights(nHid + nHid, nMid, nItem);

%% init P params
P_WU = InitLayerWeight(nHid, nFeat);
P_WI = InitBilinearWeights(nHid, nMid, nItem);
P_WC = InitBilinearWeights(nItem, nMid, nHid + nHid);

%% init Q Gradient params
QGrad_U.G = InitAdamParam;
QGrad_I.G1 = InitAdagradParam(size(Q_WI.W1)); QGrad_I.G2 = InitAdamParam;
QGrad_C.G1 = InitAdamParam; QGrad_C.G2 = InitAdagradParam(size(Q_WC.W2));

%% init P Gradient params
PGrad_U.G = InitAdamParam;
PGrad_I.G1 = InitAdamParam; PGrad_I.G2 = InitAdagradParam(size(P_WI.W2));
PGrad_C.G1 = InitAdagradParam(size(P_WC.W1)); PGrad_C.G2 = InitAdamParam;


nbatch = ceil(nCases / batchSz);
for ep = 1:Epoch
    fprintf('\nEpoch %d starting...', ep);
    
    caseData = caseData(randperm(nCases), :);
    deltaLL = 0;
    for i=1:nbatch
        [batch, actualSz] = MakeCFNetMiniBatch(dataset, caseData, FeatureDict, negItemPr, nNegSamps, i, batchSz);
        
        [feathid, Q_LL] = SampleBinaryBinaryUnits(batch.Features, Q_WU.W, nSamples);
        feathid = double(feathid);
        deltaLL = deltaLL - Q_LL;
        [itemhid, Q_LL] = SampleBinaryUnitsMulti(batch.Items, Q_WI.W1, Q_WI.W2, nSamples);
        itemhid = double(itemhid);
        deltaLL = deltaLL - Q_LL;
        midhid = [feathid; itemhid];
        Q_LL = BinarySoftmaxLL( midhid, batch.Choices, Q_WC.W1, Q_WC.W2);
        deltaLL = deltaLL - Q_LL;
        %
        P_LL = BinaryBinaryLL(batch.Choices, midhid, P_WC.W1, P_WC.W2);
        deltaLL = deltaLL + P_LL;
        P_LL = PBinaryBinaryLL( feathid, batch.Features, P_WU.W );
        deltaLL = deltaLL + P_LL;
        P_LL = BinarySoftmaxMultiLL(itemhid, batch.Items, P_WI.W1, P_WI.W2);
        deltaLL = deltaLL + P_LL;
        
        deltaLL = NormalizeLL(deltaLL);
        weights = exp(deltaLL) ./ sum(exp(deltaLL));
        
        
        f_qfeature = parfeval(@QFeatureModel, 2, batch.Features, feathid, Q_WU, QGrad_U, weights, MaxIt);
        
        % item model
        f_qitem = parfeval(@QItemModel, 2, batch.Items, itemhid, Q_WI, QGrad_I, weights, MaxIt);
        
        % output choice
        f_qchoice = parfeval(@QChoiceModel, 2, [feathid; itemhid], batch.Choices, negItemPr, batch.ItemNSamp, Q_WC, QGrad_C, weights, MaxIt);
        
        
        %% generative network
        % input choice
        f_pchoice = parfeval(@PChoiceModel, 2, batch.Choices, [feathid; itemhid],P_WC, PGrad_C, weights, MaxIt);
        
        % feature model
        f_pfeature = parfeval(@PFeatureModel, 2, feathid, batch.Features, P_WU, PGrad_U, weights, MaxIt);
        
        % item model
        f_pitem = parfeval(@PItemModel, 2, itemhid, batch.Items, negItemPr, batch.ItemNSamp, P_WI, PGrad_I, weights, MaxIt);
        
        
        %% Fetch results
        [Q_WU, QGrad_U] = fetchOutputs(f_qfeature);
        [Q_WI, QGrad_I] = fetchOutputs(f_qitem);
        [Q_WC, QGrad_C] = fetchOutputs(f_qchoice);
        
        [P_WC, PGrad_C] = fetchOutputs(f_pchoice);
        [P_WU, PGrad_U] = fetchOutputs(f_pfeature);
        [P_WI, PGrad_I] = fetchOutputs(f_pitem);
        
        fprintf('\n\tBatch %d/%d finished', i, nbatch);
    end
end

function [QParam, QGrad] = QFeatureModel(input, output, QParam, QGrad, weights)
[ gdW ] = QBinaryBinaryLayer(input, output, QParam.W, weights);
[ grad, QGrad.G ] = AdamUpdate( gdW, QGrad.G);
QParam.W = QParam.W + grad;
end

function [QParam, QGrad] = QItemModel(input, output, QParam, QGrad, weights)
[gdW1, gdW2, updateIdx] = BinaryLayerMulti(input, output, QParam.W1, QParam.W2, weights);
[ grad, QGrad.G2 ] = AdamUpdate( gdW2, QGrad.G2);
QParam.W2 = QParam.W2 + grad;
[ grad,  QGrad.G1(:,updateIdx) ] = RMSPropUpdate( gdW1, QGrad.G1(:,updateIdx));
QParam.W1(:,updateIdx) = QParam.W1(:,updateIdx) + grad;
end

function [QParam, QGrad] = QChoiceModel(input, output, negItemPr, nSamps, QParam, QGrad, weights)
[gdW1, gdW2, updateIdx, gdW2Neg, updateNegIdx] = SoftmaxLayer(input, output, negItemPr, nSamps, QParam.W1, QParam.W2, weights);
[ grad, QGrad.G1 ] = AdamUpdate( gdW1, QGrad.G1);
QParam.W1 = QParam.W1 + grad;
[ grad, QGrad.G2(updateIdx, :) ] = RMSPropUpdate( gdW2, QGrad.G2(updateIdx, :));
QParam.W2(updateIdx, :) = QParam.W2(updateIdx, :) + grad;
[ grad, QGrad.G2(updateNegIdx, :) ] = RMSPropUpdate( gdW2Neg, QGrad.G2(updateNegIdx, :));
QParam.W2(updateNegIdx, :) = QParam.W2(updateNegIdx, :) + grad;
end

function [PParam, PGrad ] = PFeatureModel(input, output, PParam, PGrad, weights)
[ gdW ] = PBinaryBinaryLayer(input, output, PParam.W, weights);
[ grad, PGrad.G ] = AdamUpdate( gdW, PGrad.G );
PParam.W = PParam.W + grad;
end

function [PParam, PGrad ] = PItemModel(input, output, negItemPr, itemNSamp, PParam, PGrad, weights)
[gdW1, gdW2, updateIdx, gdW2Neg, updateNegIdx] = SoftmaxLayerMulti(input, output, negItemPr, itemNSamp, PParam.W1, PParam.W2, weights);
[ grad, PGrad.G1 ] = AdamUpdate( gdW1, PGrad.G1);
PParam.W1 = PParam.W1 + grad;
[ grad, PGrad.G2(updateIdx, :) ] = RMSPropUpdate( gdW2, PGrad.G2(updateIdx, :));
PParam.W2(updateIdx, :) = PParam.W2(updateIdx, :) + grad;
[ grad, PGrad.G2(updateNegIdx, :) ] = RMSPropUpdate( gdW2Neg, PGrad.G2(updateNegIdx, :));
PParam.W2(updateNegIdx, :) = PParam.W2(updateNegIdx, :) + grad;
end

function [PParam, PGrad] = PChoiceModel(input, output, PParam, PGrad, weights)
[gdW1, gdW2, updateIdx] = BinaryLayer(input, output, PParam.W1, PParam.W2, weights);
[ grad, PGrad.G2 ] = AdamUpdate( gdW2, PGrad.G2);
PParam.W2 = PParam.W2 + grad;
[ grad, PGrad.G1(:,updateIdx) ] = RMSPropUpdate( gdW1, PGrad.G1(:,updateIdx));
PParam.W1(:,updateIdx) = PParam.W1(:,updateIdx) + grad;
end