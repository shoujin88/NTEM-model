items = {[8], [1,2], [3,5], [11,13]};
itemhid = BinaryForwardMulti( items, Q_WI.W1, Q_WI.W2 );
scores = OutScores( itemhid, Q_WC.W1, Q_WC.W2 );
[~, rankItemsOnly] = sort(scores, 'descend');